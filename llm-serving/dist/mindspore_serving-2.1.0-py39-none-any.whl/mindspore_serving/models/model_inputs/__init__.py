from .internlm_inputs import *
from .llama_inputs import *
from .wizardcoder_inputs import *
#from .baichuan2pa_inputs import *
__all__ = []
__all__.extend(internlm_inputs.__all__)
__all__.extend(llama_inputs.__all__)
__all__.extend(wizardcoder_inputs.__all__)
#__all__.extend(baichuan2pa_inputs.__all__)